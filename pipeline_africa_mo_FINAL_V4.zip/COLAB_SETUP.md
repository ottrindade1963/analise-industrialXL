# Guia de Execução no Google Colab

## Pré-requisitos

1. Conta Google (para acessar Google Drive e Colab)
2. Repositório GitHub com o pipeline (URL do repositório)
3. Acesso ao Google Drive para sincronização de resultados

## Execução Recomendada (GitHub + Drive)

### Passo 1: Preparar o Colab

```python
# Célula 1: Montar Google Drive
from google.colab import drive
drive.mount('/content/drive')
print("✓ Google Drive montado")
```

### Passo 2: Instalar Dependências

```python
# Célula 2: Instalar dependências
!pip install -q wbgapi pmdarima xgboost shap geopandas pymc arviz tensorflow scipy
print("✓ Dependências instaladas")
```

### Passo 3: Clonar Repositório GitHub

```python
# Célula 3: Clonar repositório
!git clone https://github.com/seu-usuario/seu-repositorio.git /content/repo
print("✓ Repositório clonado")
```

### Passo 4: Executar o Notebook

No menu do Colab: **Runtime → Run all** para executar todas as células.

Ou execute célula por célula para debugging.

---

## Sincronização Automática com Drive

O notebook sincroniza **TODOS os ficheiros gerados simultaneamente** após cada passo:

```
Após cada passo:
├── Ficheiros locais (Colab): /content/repo/pipeline_africa_mo/
└── Ficheiros no Drive: /MyDrive/pipeline_africa_mo_resultados/
    ├── dados_brutos/
    ├── dados_limpos/
    ├── dados_agregados/
    ├── dados_sinteticos/
    ├── dados_engenharia/
    ├── eda_brutos/
    ├── eda_agregados/
    ├── modelos_treinados/
    ├── resultados_avaliacao/
    ├── analise_estrategias/
    ├── shap_analysis/
    ├── analise_geografica/
    ├── analise_avancada/
    └── metadados/
```

---

## Troubleshooting

### Erro: "fatal: could not read Username for 'https://github.com'"

**Solução:** Se o repositório é privado, usar token de acesso:

```python
!git clone https://seu-token@github.com/seu-usuario/seu-repositorio.git /content/repo
```

Ou configurar credenciais:

```python
!git config --global user.email "seu-email@example.com"
!git config --global user.name "Seu Nome"
```

### Erro: "ModuleNotFoundError: No module named 'wbgapi'"

**Solução:** Instalar dependências

```python
!pip install -q wbgapi pmdarima xgboost shap geopandas pymc arviz tensorflow scipy
```

### Erro: "API rate limit exceeded" (WDI)

**Solução:** Aguardar alguns minutos e tentar novamente

### Timeout no Passo 4 (Treino de Modelos)

**Solução:** O treino pode demorar 1-2 horas. Usar GPU do Colab:

1. **Runtime → Change runtime type → GPU**
2. Executar novamente

---

## Dicas de Performance

1. **Use GPU para Passo 4 (Treino):** Runtime → Change runtime type → GPU
2. **Reduza parâmetros para teste rápido:** Editar `config_global.py`
3. **Execute passos individuais:** Não precisa executar tudo de uma vez
4. **Monitore o Drive:** Ficheiros são sincronizados automaticamente após cada passo

---

## Atualizar Repositório GitHub com Resultados

Após execução completa, você pode fazer push dos resultados:

```python
# Célula final (após Passo 9)
!cd /content/repo && git add -A && git commit -m "Resultados pipeline $(date +%Y-%m-%d_%H:%M:%S)" && git push
print("✓ Resultados enviados para o GitHub")
```

**Nota:** Esta célula está comentada no notebook por padrão. Descomente se quiser usar.

---

## Fluxo de Sincronização

```
Colab (Local)
    ↓
    └─→ Passo 1: Extração
        └─→ Sincroniza TODOS os ficheiros com Drive
    ↓
    └─→ Passo 2: EDA Brutos
        └─→ Sincroniza TODOS os ficheiros com Drive
    ↓
    ... (Passos 2.1 a 9)
    ↓
    └─→ Passo 9: Análises Avançadas
        └─→ Sincroniza TODOS os ficheiros com Drive
    ↓
Google Drive
    ├── pipeline_africa_mo_resultados/
    │   ├── dados_brutos/
    │   ├── dados_limpos/
    │   ├── dados_agregados/
    │   ├── dados_sinteticos/
    │   ├── dados_engenharia/
    │   ├── eda_brutos/
    │   ├── eda_agregados/
    │   ├── modelos_treinados/
    │   ├── resultados_avaliacao/
    │   ├── analise_estrategias/
    │   ├── shap_analysis/
    │   ├── analise_geografica/
    │   ├── analise_avancada/
    │   └── metadados/
    └── (GitHub opcional: git push)
```
