# Pipeline de Análise Industrial - África e Médio Oriente

## Visão Geral

Pipeline completo de análise de dados para estudo do valor agregado industrial em 37 países da África e Médio Oriente, utilizando dados do Banco Mundial (WDI + WGI) com geração automática de metadados em cada passo.

## Estrutura do Pipeline

| Passo | Ficheiro | Descrição |
|-------|----------|-----------|
| 1 | `passo1_extracao.py` | Extração de dados reais via API (WDI + WGI) |
| 2 | `passo2_eda_brutos.py` | Análise Exploratória dos dados brutos |
| 2.1 | `passo2_1_limpeza.py` | Limpeza e EDA (WDI + WGI) |
| 2.2 | `passo2_2_agregacao_sinteticos.py` | Agregação INNER JOIN + Dados Sintéticos (500 anos) |
| 2.3 | `passo2_3_eda_agregados.py` | EDA Agregados + EDA Sintéticos |
| 3 | `passo3_engenharia_features.py` | Engenharia de Features avançada |
| 4 | `passo4_treino_modelos.py` | Treinamento de 7 Modelos (5 Clássicos + 2 Bayesianos) |
| 5 | `passo5_avaliacao.py` | Avaliação de Performance |
| 6 | `passo6_estrategias.py` | Análise de Estratégias |
| 7 | `passo7_shap.py` | Interpretabilidade (SHAP) |
| 8 | `passo8_geografica.py` | Análise Geográfica |
| 9 | `passo9_avancada.py` | Análises Avançadas |

## Ficheiros de Suporte

| Ficheiro | Função |
|----------|--------|
| `config_global.py` | Configuração global (países, indicadores, parâmetros) |
| `metadata_generator.py` | Geração automática de metadados JSON |
| `Pipeline_Africa_MO_Completo.py` | Execução sequencial de todos os passos |

## Engenharia de Features (Passo 3)

- **Lags 1, 2, 3** para variáveis qualitativas (WGI)
- **Lags 1** para variáveis quantitativas
- **Lags 1, 2** da variável alvo (autorregressivos)
- **Médias móveis de 3 anos** para WGI
- **Diferenças (deltas)** das variáveis qualitativas
- **Log-retornos** para variáveis quantitativas
- **Termos de interação defasados** (Hipótese H2)

## Modelos (Passo 4)

1. **Random Forest** (RandomizedSearchCV, 100 iterações)
2. **XGBoost** (Early Stopping, 1000 estimadores)
3. **TFT/GradientBoosting** (RandomizedSearchCV, 100 iterações)
4. **SARIMAX** (auto_arima via pmdarima, por país)
5. **LSTM** (Keras, 2 camadas, lookback=5)
6. **Bayes_PartialPooling** (PyMC hierárquico)
7. **Bayes_CompletePooling** (PyMC)

## Requisitos

```bash
pip install wbgapi pandas numpy matplotlib seaborn scikit-learn xgboost \
    pmdarima shap geopandas pymc arviz tensorflow scipy
```

## Execução no Google Colab

```python
# 1. Montar Google Drive
from google.colab import drive
drive.mount('/content/drive')

# 2. Extrair ZIP
!unzip -q /content/drive/MyDrive/pipeline_africa_mo.zip -d /content/

# 3. Executar pipeline completo
%cd /content/pipeline_africa_mo
%run Pipeline_Africa_MO_Completo.py
```

## Países Incluídos (37)

África Subsaariana: Angola, Botsuana, Camarões, Costa do Marfim, RD Congo, Etiópia, Gabão, Gana, Quénia, Madagáscar, Moçambique, Maurícia, Nigéria, Ruanda, Senegal, África do Sul, Tanzânia, Uganda, Zâmbia, Zimbabué

Norte de África: Argélia, Egito, Líbia, Marrocos, Tunísia

Médio Oriente: Bahrein, Irão, Iraque, Jordânia, Kuwait, Líbano, Omã, Qatar, Arábia Saudita, Turquia, Emirados Árabes Unidos, Iémen

## Variável Alvo

`valor_agregado_industrial_percent_pib` (NV.IND.TOTL.ZS) - Valor agregado da indústria como percentagem do PIB.

## Dados Sintéticos

Extrapolação para 500 anos usando tendência linear atenuada com decaimento exponencial e ruído gaussiano baseado nos resíduos históricos. Garante valores fisicamente plausíveis.

## Metadados

Cada passo gera automaticamente um ficheiro JSON em `metadados/` com:
- Timestamp de execução
- Parâmetros utilizados
- Ficheiros de entrada e saída
- Métricas calculadas
- Informação do dataset (shape, tipos, missing)
